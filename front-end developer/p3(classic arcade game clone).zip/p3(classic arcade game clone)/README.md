frontend-nanodegree-arcade-game
===============================
Open the inedx.html using a browser, and player will see the game running. 
This is a classic arcade game clone for the game frogger. Player's objective is to move the character to water with arrow keys. In the process, the character should not touch any of the bugs, otherwise the position will be reset. Once the player reach the water, the position will be reset.
